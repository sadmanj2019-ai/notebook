package com.sadman.notebook.data

import androidx.room.Entity
import androidx.room.PrimaryKey

const val NEW_NOTE_ID = -1L

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val isPinned: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis(),
    val color: Int = 0,
    val isChecklist: Boolean = false,
    val isArchived: Boolean = false,
    val label: String = "",
    /** 0 means the note is not in the trash; otherwise the time it was trashed. */
    val deletedAt: Long = 0L
)

data class ChecklistItem(val text: String, val checked: Boolean)

/** Checklist items are stored one per line as "0|text" (open) or "1|text" (done). */
object ChecklistCodec {
    fun decode(content: String): List<ChecklistItem> =
        if (content.isEmpty()) emptyList()
        else content.split("\n").map { line ->
            if (line.length >= 2 && line[1] == '|') {
                ChecklistItem(text = line.substring(2), checked = line[0] == '1')
            } else {
                ChecklistItem(text = line, checked = false)
            }
        }

    fun encode(items: List<ChecklistItem>): String =
        items.joinToString("\n") { (if (it.checked) "1|" else "0|") + it.text.replace("\n", " ") }

    fun toPlain(items: List<ChecklistItem>): String =
        items.joinToString("\n") { (if (it.checked) "☑ " else "☐ ") + it.text }
}

fun isContentBlank(content: String, isChecklist: Boolean): Boolean =
    if (isChecklist) ChecklistCodec.decode(content).all { it.text.isBlank() }
    else content.isBlank()

/** The note body as plain text, with checklist items drawn as ☐ / ☑ lines. */
fun Note.plainContent(): String =
    if (isChecklist) {
        ChecklistCodec.toPlain(ChecklistCodec.decode(content).filter { it.text.isNotBlank() })
    } else {
        content
    }

/** The title, or the first line of the note when no title was typed. */
fun Note.displayTitle(): String =
    title.ifBlank {
        plainContent().lineSequence().firstOrNull { it.isNotBlank() }?.trim()?.take(40).orEmpty()
    }
