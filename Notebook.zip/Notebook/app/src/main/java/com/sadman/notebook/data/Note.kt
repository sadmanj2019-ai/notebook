package com.sadman.notebook.data

import androidx.room.Entity
import androidx.room.PrimaryKey

const val NEW_NOTE_ID = -1L

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val isPinned: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)
