package com.sadman.notebook.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sadman.notebook.data.AppDatabase
import com.sadman.notebook.data.NEW_NOTE_ID
import com.sadman.notebook.data.Note
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NotesViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = AppDatabase.get(app).noteDao()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    val notes: StateFlow<List<Note>> = combine(dao.observeAll(), _query) { list, q ->
        if (q.isBlank()) list
        else list.filter {
            it.title.contains(q, ignoreCase = true) || it.content.contains(q, ignoreCase = true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun onQueryChange(value: String) {
        _query.value = value
    }

    suspend fun load(id: Long): Note? = dao.getById(id)

    fun save(id: Long, title: String, content: String, pinned: Boolean) {
        viewModelScope.launch {
            val isNew = id == NEW_NOTE_ID
            if (title.isBlank() && content.isBlank()) {
                // A blank note is not worth keeping.
                if (!isNew) dao.getById(id)?.let { dao.delete(it) }
                return@launch
            }
            dao.upsert(
                Note(
                    id = if (isNew) 0 else id,
                    title = title.trim(),
                    content = content,
                    isPinned = pinned,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    fun togglePin(note: Note) {
        viewModelScope.launch { dao.upsert(note.copy(isPinned = !note.isPinned)) }
    }

    fun delete(note: Note) {
        viewModelScope.launch { dao.delete(note) }
    }
}
