package com.sadman.notebook.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sadman.notebook.data.AppDatabase
import com.sadman.notebook.data.NEW_NOTE_ID
import com.sadman.notebook.data.Note
import com.sadman.notebook.data.isContentBlank
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

enum class Section { NOTES, ARCHIVE, TRASH }

private const val TRASH_KEEP_MILLIS = 30L * 24 * 60 * 60 * 1000

class NotesViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = AppDatabase.get(app).noteDao()

    private val allNotes: StateFlow<List<Note>> = dao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _section = MutableStateFlow(Section.NOTES)
    val section: StateFlow<Section> = _section.asStateFlow()

    private val _labelFilter = MutableStateFlow("")
    val labelFilter: StateFlow<String> = _labelFilter.asStateFlow()

    private val _gridMode = MutableStateFlow(true)
    val gridMode: StateFlow<Boolean> = _gridMode.asStateFlow()

    val notes: StateFlow<List<Note>> = combine(allNotes, _query, _section, _labelFilter) { all, q, s, l ->
        filterNotes(all, q, s, l)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val labels: StateFlow<List<String>> = allNotes.map { list ->
        list.filter { it.deletedAt == 0L }
            .map { it.label }
            .filter { it.isNotBlank() }
            .distinct()
            .sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        // Trash is emptied automatically after 30 days.
        viewModelScope.launch {
            dao.purgeTrashedBefore(System.currentTimeMillis() - TRASH_KEEP_MILLIS)
        }
    }

    private fun filterNotes(all: List<Note>, query: String, section: Section, label: String): List<Note> {
        val inSection = all.filter {
            when (section) {
                Section.NOTES -> it.deletedAt == 0L && !it.isArchived
                Section.ARCHIVE -> it.deletedAt == 0L && it.isArchived
                Section.TRASH -> it.deletedAt > 0L
            }
        }
        val labelStillExists = label.isNotBlank() && all.any { it.deletedAt == 0L && it.label == label }
        val byLabel =
            if (labelStillExists && section != Section.TRASH) inSection.filter { it.label == label }
            else inSection
        return if (query.isBlank()) byLabel
        else byLabel.filter {
            it.title.contains(query, ignoreCase = true) ||
                it.content.contains(query, ignoreCase = true) ||
                it.label.contains(query, ignoreCase = true)
        }
    }

    fun onQueryChange(value: String) {
        _query.value = value
    }

    fun setSection(value: Section) {
        _section.value = value
        _labelFilter.value = ""
    }

    fun setLabelFilter(value: String) {
        _labelFilter.value = value
    }

    fun toggleGridMode() {
        _gridMode.value = !_gridMode.value
    }

    suspend fun load(id: Long): Note? = dao.getById(id)

    fun save(
        id: Long,
        title: String,
        content: String,
        pinned: Boolean,
        color: Int,
        isChecklist: Boolean,
        archived: Boolean,
        label: String
    ) {
        viewModelScope.launch {
            val isNew = id == NEW_NOTE_ID
            val existing = if (isNew) null else dao.getById(id)
            if (title.isBlank() && isContentBlank(content, isChecklist)) {
                // A blank note is not worth keeping.
                existing?.let { dao.delete(it) }
                return@launch
            }
            val candidate = Note(
                id = if (isNew) 0 else id,
                title = title.trim(),
                content = content,
                isPinned = pinned,
                updatedAt = existing?.updatedAt ?: System.currentTimeMillis(),
                color = color,
                isChecklist = isChecklist,
                isArchived = archived,
                label = label.trim(),
                deletedAt = existing?.deletedAt ?: 0L
            )
            // Nothing changed: keep the note where it is in the list.
            if (existing != null && candidate == existing) return@launch
            dao.upsert(candidate.copy(updatedAt = System.currentTimeMillis()))
        }
    }

    fun togglePin(note: Note) {
        viewModelScope.launch { dao.upsert(note.copy(isPinned = !note.isPinned)) }
    }

    fun toggleArchive(note: Note) {
        viewModelScope.launch {
            dao.upsert(note.copy(isArchived = !note.isArchived, isPinned = false))
        }
    }

    fun trash(note: Note) {
        viewModelScope.launch {
            dao.upsert(note.copy(deletedAt = System.currentTimeMillis(), isPinned = false))
        }
    }

    fun trashById(id: Long) {
        viewModelScope.launch {
            dao.getById(id)?.let {
                dao.upsert(it.copy(deletedAt = System.currentTimeMillis(), isPinned = false))
            }
        }
    }

    fun restore(note: Note) {
        viewModelScope.launch { dao.upsert(note.copy(deletedAt = 0L)) }
    }

    fun deleteForever(note: Note) {
        viewModelScope.launch { dao.delete(note) }
    }

    fun emptyTrash() {
        viewModelScope.launch { dao.deleteAllTrashed() }
    }

    /** All notes (including archived ones) as a JSON text, for a backup file. */
    suspend fun exportJson(): String {
        val array = JSONArray()
        dao.getAllOnce().filter { it.deletedAt == 0L }.forEach { n ->
            array.put(
                JSONObject()
                    .put("title", n.title)
                    .put("content", n.content)
                    .put("pinned", n.isPinned)
                    .put("updatedAt", n.updatedAt)
                    .put("color", n.color)
                    .put("checklist", n.isChecklist)
                    .put("archived", n.isArchived)
                    .put("label", n.label)
            )
        }
        return JSONObject()
            .put("app", "notebook")
            .put("version", 1)
            .put("notes", array)
            .toString(2)
    }

    /** Adds notes from a backup. Returns how many were new, or -1 if the file is not a valid backup. */
    suspend fun importJson(json: String): Int {
        return try {
            val array = JSONObject(json).getJSONArray("notes")
            val existing = dao.getAllOnce()
                .map { Triple(it.title, it.content, it.updatedAt) }
                .toSet()
            val fresh = mutableListOf<Note>()
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                val note = Note(
                    id = 0,
                    title = o.optString("title"),
                    content = o.optString("content"),
                    isPinned = o.optBoolean("pinned"),
                    updatedAt = o.optLong("updatedAt", System.currentTimeMillis()),
                    color = o.optInt("color"),
                    isChecklist = o.optBoolean("checklist"),
                    isArchived = o.optBoolean("archived"),
                    label = o.optString("label"),
                    deletedAt = 0L
                )
                if (Triple(note.title, note.content, note.updatedAt) !in existing) fresh.add(note)
            }
            dao.insertAll(fresh)
            fresh.size
        } catch (e: Exception) {
            -1
        }
    }
}
