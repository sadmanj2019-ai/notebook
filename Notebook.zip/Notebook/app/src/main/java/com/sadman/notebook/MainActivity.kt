package com.sadman.notebook

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.sadman.notebook.data.NEW_NOTE_ID
import com.sadman.notebook.ui.EditorScreen
import com.sadman.notebook.ui.NotebookTheme
import com.sadman.notebook.ui.NotesListScreen
import com.sadman.notebook.ui.NotesViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NotebookTheme {
                NotebookApp()
            }
        }
    }
}

@Composable
fun NotebookApp(viewModel: NotesViewModel = viewModel()) {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "list") {
        composable("list") {
            NotesListScreen(
                viewModel = viewModel,
                onOpen = { id -> nav.navigate("editor/$id") }
            )
        }
        composable(
            route = "editor/{id}",
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) { entry ->
            EditorScreen(
                viewModel = viewModel,
                noteId = entry.arguments?.getLong("id") ?: NEW_NOTE_ID,
                onClose = { nav.popBackStack() }
            )
        }
    }
}
