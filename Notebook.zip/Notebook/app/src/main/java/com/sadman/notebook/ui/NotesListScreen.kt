package com.sadman.notebook.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sadman.notebook.R
import com.sadman.notebook.data.NEW_NOTE_ID
import com.sadman.notebook.data.Note
import com.sadman.notebook.data.displayTitle
import com.sadman.notebook.data.plainContent
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesListScreen(
    viewModel: NotesViewModel,
    onOpen: (Long) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val notes by viewModel.notes.collectAsStateWithLifecycle()
    val query by viewModel.query.collectAsStateWithLifecycle()
    val section by viewModel.section.collectAsStateWithLifecycle()
    val labels by viewModel.labels.collectAsStateWithLifecycle()
    val labelFilter by viewModel.labelFilter.collectAsStateWithLifecycle()
    val gridMode by viewModel.gridMode.collectAsStateWithLifecycle()

    var menuOpen by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<Note?>(null) }
    var confirmEmptyTrash by remember { mutableStateOf(false) }

    val exportOk = stringResource(R.string.export_ok)
    val exportFail = stringResource(R.string.export_fail)
    val importFail = stringResource(R.string.import_fail)
    val importOkTemplate = stringResource(R.string.import_ok)

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val json = viewModel.exportJson()
                val ok = runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
                }.isSuccess
                Toast.makeText(context, if (ok) exportOk else exportFail, Toast.LENGTH_SHORT).show()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val text = runCatching {
                    context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                }.getOrNull()
                val count = if (text == null) -1 else viewModel.importJson(text)
                val message = if (count < 0) importFail else String.format(importOkTemplate, count)
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            Column {
                CenterAlignedTopAppBar(
                    title = { Text(stringResource(R.string.app_name)) },
                    actions = {
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Filled.MoreVert, contentDescription = stringResource(R.string.more))
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = {
                                        Text(stringResource(if (gridMode) R.string.menu_list else R.string.menu_grid))
                                    },
                                    onClick = {
                                        viewModel.toggleGridMode()
                                        menuOpen = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.menu_export)) },
                                    onClick = {
                                        menuOpen = false
                                        exportLauncher.launch("notebook-backup.json")
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.menu_import)) },
                                    onClick = {
                                        menuOpen = false
                                        importLauncher.launch(arrayOf("*/*"))
                                    }
                                )
                                if (section == Section.TRASH && notes.isNotEmpty()) {
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.menu_empty_trash)) },
                                        onClick = {
                                            menuOpen = false
                                            confirmEmptyTrash = true
                                        }
                                    )
                                }
                            }
                        }
                    }
                )
                TabRow(selectedTabIndex = section.ordinal) {
                    Section.entries.forEach { s ->
                        Tab(
                            selected = section == s,
                            onClick = { viewModel.setSection(s) },
                            text = {
                                Text(
                                    stringResource(
                                        when (s) {
                                            Section.NOTES -> R.string.tab_notes
                                            Section.ARCHIVE -> R.string.tab_archive
                                            Section.TRASH -> R.string.tab_trash
                                        }
                                    )
                                )
                            }
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (section != Section.TRASH) {
                FloatingActionButton(onClick = { onOpen(NEW_NOTE_ID) }) {
                    Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.new_note))
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = viewModel::onQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text(stringResource(R.string.search_hint)) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { viewModel.onQueryChange("") }) {
                            Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.clear))
                        }
                    }
                },
                singleLine = true
            )

            if (section == Section.TRASH) {
                Text(
                    text = stringResource(R.string.trash_info),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }

            if (section != Section.TRASH && labels.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = labelFilter.isBlank(),
                        onClick = { viewModel.setLabelFilter("") },
                        label = { Text(stringResource(R.string.all_labels)) }
                    )
                    labels.forEach { l ->
                        FilterChip(
                            selected = labelFilter == l,
                            onClick = { viewModel.setLabelFilter(l) },
                            label = { Text(l) }
                        )
                    }
                }
            }

            if (notes.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = stringResource(
                            when {
                                query.isNotBlank() -> R.string.no_results
                                section == Section.ARCHIVE -> R.string.empty_archive
                                section == Section.TRASH -> R.string.empty_trash
                                else -> R.string.empty_notes
                            }
                        ),
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(32.dp)
                    )
                }
            } else {
                val inTrash = section == Section.TRASH
                val card: @Composable (Note) -> Unit = { note ->
                    NoteCard(
                        note = note,
                        inTrash = inTrash,
                        onClick = { if (!inTrash) onOpen(note.id) },
                        onTogglePin = { viewModel.togglePin(note) },
                        onArchive = { viewModel.toggleArchive(note) },
                        onTrash = { viewModel.trash(note) },
                        onShare = {
                            val body = listOf(note.title, note.plainContent())
                                .filter { it.isNotBlank() }
                                .joinToString("\n\n")
                            shareText(context, note.displayTitle(), body)
                        },
                        onRestore = { viewModel.restore(note) },
                        onDeleteForever = { deleteTarget = note }
                    )
                }
                if (gridMode) {
                    LazyVerticalStaggeredGrid(
                        columns = StaggeredGridCells.Fixed(2),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 88.dp),
                        verticalItemSpacing = 12.dp,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(items = notes, key = { it.id }) { note -> card(note) }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 88.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(items = notes, key = { it.id }) { note -> card(note) }
                    }
                }
            }
        }
    }

    deleteTarget?.let { note ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text(stringResource(R.string.delete_forever_title)) },
            text = { Text(stringResource(R.string.delete_forever_message)) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteForever(note)
                    deleteTarget = null
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    if (confirmEmptyTrash) {
        AlertDialog(
            onDismissRequest = { confirmEmptyTrash = false },
            title = { Text(stringResource(R.string.empty_trash_title)) },
            text = { Text(stringResource(R.string.empty_trash_message)) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.emptyTrash()
                    confirmEmptyTrash = false
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmEmptyTrash = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}

@Composable
private fun NoteCard(
    note: Note,
    inTrash: Boolean,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    onArchive: () -> Unit,
    onTrash: () -> Unit,
    onShare: () -> Unit,
    onRestore: () -> Unit,
    onDeleteForever: () -> Unit
) {
    val container = noteContainerColor(note.color)
    val colors = if (container == null) {
        CardDefaults.cardColors()
    } else {
        CardDefaults.cardColors(containerColor = container, contentColor = NoteTextColor)
    }

    val plain = note.plainContent()
    val titleText = note.displayTitle().ifBlank { stringResource(R.string.untitled) }
    // When there is no typed title, the first line already became the title.
    val bodyText = if (note.title.isBlank()) {
        plain.lines().dropWhile { it.isBlank() }.drop(1).joinToString("\n").trim()
    } else {
        plain.trim()
    }

    var menuOpen by remember { mutableStateOf(false) }

    Card(onClick = onClick, colors = colors, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(start = 14.dp, top = 8.dp, bottom = 4.dp, end = 4.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Text(
                    text = titleText,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .weight(1f)
                        .padding(top = 8.dp)
                )
                if (!inTrash) {
                    IconButton(onClick = onTogglePin) {
                        Icon(
                            imageVector = if (note.isPinned) Icons.Filled.Star else Icons.Outlined.Star,
                            contentDescription = stringResource(if (note.isPinned) R.string.unpin else R.string.pin)
                        )
                    }
                }
            }
            if (bodyText.isNotBlank()) {
                Text(
                    text = bodyText,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 8,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(end = 10.dp)
                )
            }
            if (note.label.isNotBlank()) {
                Text(
                    text = "#" + note.label,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
                        .format(Date(note.updatedAt)),
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.weight(1f)
                )
                if (!inTrash) {
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = stringResource(R.string.more))
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        stringResource(
                                            if (note.isArchived) R.string.action_unarchive else R.string.action_archive
                                        )
                                    )
                                },
                                onClick = {
                                    menuOpen = false
                                    onArchive()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.action_share)) },
                                onClick = {
                                    menuOpen = false
                                    onShare()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.action_trash)) },
                                onClick = {
                                    menuOpen = false
                                    onTrash()
                                }
                            )
                        }
                    }
                }
            }
            if (inTrash) {
                Row {
                    TextButton(onClick = onRestore) { Text(stringResource(R.string.action_restore)) }
                    TextButton(onClick = onDeleteForever) { Text(stringResource(R.string.action_delete_forever)) }
                }
            }
        }
    }
}
