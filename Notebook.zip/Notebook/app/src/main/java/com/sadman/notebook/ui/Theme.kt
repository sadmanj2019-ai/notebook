package com.sadman.notebook.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

/** Note colours. Index 0 means "no colour"; indexes 1..7 are these pastel shades. */
val NotePalette = listOf(
    Color(0xFFFFF59D), // yellow
    Color(0xFFFFCCBC), // orange
    Color(0xFFF8BBD0), // pink
    Color(0xFFE1BEE7), // purple
    Color(0xFFBBDEFB), // blue
    Color(0xFFC8E6C9), // green
    Color(0xFFD7CCC8)  // brown
)

/** Dark text that stays readable on every pastel shade, in light and dark mode. */
val NoteTextColor = Color(0xFF1C1B1F)

fun noteContainerColor(index: Int): Color? =
    if (index <= 0) null else NotePalette.getOrNull(index - 1)

@Composable
fun NotebookTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val context = LocalContext.current
    val colors = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = colors, content = content)
}
