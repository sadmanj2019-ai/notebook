package com.sadman.notebook.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sadman.notebook.R
import com.sadman.notebook.data.ChecklistCodec
import com.sadman.notebook.data.ChecklistItem
import com.sadman.notebook.data.NEW_NOTE_ID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    viewModel: NotesViewModel,
    noteId: Long,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val isNew = noteId == NEW_NOTE_ID
    val existingLabels by viewModel.labels.collectAsStateWithLifecycle()

    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var pinned by remember { mutableStateOf(false) }
    var color by remember { mutableStateOf(0) }
    var label by remember { mutableStateOf("") }
    var isChecklist by remember { mutableStateOf(false) }
    var archived by remember { mutableStateOf(false) }
    val items = remember { mutableStateListOf<ChecklistItem>() }
    var loaded by remember(noteId) { mutableStateOf(isNew) }
    var menuOpen by remember { mutableStateOf(false) }

    LaunchedEffect(noteId) {
        if (!loaded) {
            viewModel.load(noteId)?.let { n ->
                title = n.title
                pinned = n.isPinned
                color = n.color
                label = n.label
                archived = n.isArchived
                isChecklist = n.isChecklist
                if (n.isChecklist) {
                    items.clear()
                    items.addAll(ChecklistCodec.decode(n.content))
                } else {
                    content = n.content
                }
            }
            loaded = true
        }
    }

    fun bodyForSave(): String =
        if (isChecklist) ChecklistCodec.encode(items.toList()) else content

    fun saveAndClose(archiveValue: Boolean = archived) {
        viewModel.save(
            id = noteId,
            title = title,
            content = bodyForSave(),
            pinned = pinned,
            color = color,
            isChecklist = isChecklist,
            archived = archiveValue,
            label = label
        )
        onClose()
    }

    fun toggleChecklist() {
        if (!isChecklist) {
            items.clear()
            content.lines().filter { it.isNotBlank() }.forEach { items.add(ChecklistItem(it.trim(), false)) }
            if (items.isEmpty()) items.add(ChecklistItem("", false))
            isChecklist = true
        } else {
            content = items.joinToString("\n") { it.text }
            isChecklist = false
        }
    }

    // The system back gesture saves the note too.
    BackHandler { saveAndClose() }

    val container = noteContainerColor(color)
    val background = container ?: MaterialTheme.colorScheme.background
    val textColor = if (container != null) NoteTextColor else MaterialTheme.colorScheme.onSurface
    val hintColor = textColor.copy(alpha = 0.5f)

    val fieldColors = TextFieldDefaults.colors(
        focusedContainerColor = Color.Transparent,
        unfocusedContainerColor = Color.Transparent,
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent,
        focusedTextColor = textColor,
        unfocusedTextColor = textColor,
        focusedPlaceholderColor = hintColor,
        unfocusedPlaceholderColor = hintColor
    )

    Scaffold(
        containerColor = background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = background,
                    titleContentColor = textColor,
                    navigationIconContentColor = textColor,
                    actionIconContentColor = textColor
                ),
                title = {
                    Text(stringResource(if (isNew) R.string.new_note else R.string.edit_note))
                },
                navigationIcon = {
                    IconButton(onClick = { saveAndClose() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { toggleChecklist() }) {
                        Icon(
                            Icons.Filled.Check,
                            contentDescription = stringResource(R.string.checklist_mode)
                        )
                    }
                    IconButton(onClick = { pinned = !pinned }) {
                        Icon(
                            imageVector = if (pinned) Icons.Filled.Star else Icons.Outlined.Star,
                            contentDescription = stringResource(if (pinned) R.string.unpin else R.string.pin)
                        )
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = stringResource(R.string.more))
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        stringResource(
                                            if (archived) R.string.action_unarchive else R.string.action_archive
                                        )
                                    )
                                },
                                onClick = {
                                    menuOpen = false
                                    saveAndClose(archiveValue = !archived)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.action_share)) },
                                onClick = {
                                    menuOpen = false
                                    val bodyPlain = if (isChecklist) {
                                        ChecklistCodec.toPlain(items.filter { it.text.isNotBlank() })
                                    } else {
                                        content
                                    }
                                    val text = listOf(title, bodyPlain)
                                        .filter { it.isNotBlank() }
                                        .joinToString("\n\n")
                                    shareText(context, title, text)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.action_trash)) },
                                onClick = {
                                    menuOpen = false
                                    if (!isNew) viewModel.trashById(noteId)
                                    onClose()
                                }
                            )
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .verticalScroll(rememberScrollState())
        ) {
            TextField(
                value = title,
                onValueChange = { title = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = {
                    Text(
                        stringResource(R.string.title_hint),
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                textStyle = MaterialTheme.typography.titleLarge,
                colors = fieldColors,
                singleLine = true
            )

            if (isChecklist) {
                items.forEachIndexed { index, item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = item.checked,
                            onCheckedChange = { items[index] = item.copy(checked = it) }
                        )
                        TextField(
                            value = item.text,
                            onValueChange = { items[index] = item.copy(text = it.replace("\n", " ")) },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text(stringResource(R.string.item_hint)) },
                            textStyle = LocalTextStyle.current.copy(
                                textDecoration = if (item.checked) TextDecoration.LineThrough else TextDecoration.None
                            ),
                            colors = fieldColors,
                            singleLine = true
                        )
                        IconButton(onClick = { items.removeAt(index) }) {
                            Icon(
                                Icons.Filled.Close,
                                contentDescription = stringResource(R.string.remove_item),
                                tint = textColor
                            )
                        }
                    }
                }
                TextButton(
                    onClick = { items.add(ChecklistItem("", false)) },
                    modifier = Modifier.padding(start = 12.dp)
                ) {
                    Text(stringResource(R.string.add_item), color = textColor)
                }
            } else {
                TextField(
                    value = content,
                    onValueChange = { content = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text(stringResource(R.string.content_hint)) },
                    colors = fieldColors,
                    minLines = 10
                )
            }

            Spacer(Modifier.height(8.dp))

            // Colour picker: the first circle means "no colour".
            Row(
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                for (index in 0..NotePalette.size) {
                    val swatch = noteContainerColor(index) ?: MaterialTheme.colorScheme.surfaceVariant
                    val selected = color == index
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(swatch)
                            .border(
                                width = if (selected) 3.dp else 1.dp,
                                color = if (selected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outline,
                                shape = CircleShape
                            )
                            .clickable { color = index }
                    )
                }
            }

            TextField(
                value = label,
                onValueChange = { label = it.take(24) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(stringResource(R.string.label_hint)) },
                colors = fieldColors,
                singleLine = true
            )

            if (existingLabels.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    existingLabels.forEach { l ->
                        FilterChip(
                            selected = label == l,
                            onClick = { label = if (label == l) "" else l },
                            label = { Text(l) }
                        )
                    }
                }
            }

            val stats = if (isChecklist) {
                val real = items.filter { it.text.isNotBlank() }
                stringResource(R.string.stats_checklist, real.count { it.checked }, real.size)
            } else {
                val words = content.trim().split(Regex("\\s+")).count { it.isNotBlank() }
                stringResource(R.string.stats_text, words, content.length)
            }
            Text(
                text = stats,
                style = MaterialTheme.typography.labelMedium,
                color = textColor.copy(alpha = 0.7f),
                modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 32.dp)
            )
        }
    }
}
